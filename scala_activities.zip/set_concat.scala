object set_concat {
   def main(args: Array[String]) : Unit =  {
      val brand1 = Set("dell", "ibm","lenovo","acer")
      val brand2 = Set("sony","toshiba","apple","asus")
        // use two or more sets with ++ as operator
      var brand = brand1 ++ brand2
      println( "brand1 ++ brand2 : " + brand )

      // use two sets with ++ as method
      brand = brand1.++(brand2)
      println( "brand1.++(brand2) : " + brand)
    
   }
}


