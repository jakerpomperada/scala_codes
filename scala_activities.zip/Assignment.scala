
object Assignment {

def main(args: Array[String]) : Unit = {
var x = 50;
var y = 40;
var z = 0;

print("\n")
print("\tAssignment Operators in Scala")
print("\n\n")

z = x + y;

println("\tz= x+ y = " + z );
print("\n")
z+= x ;
println("\tAdd and assignment of z += x = " + z );

z -= x ;
println("\tSubtract and assignment of z -= x = " + z );

z *= x ;
println("\tMultiplication and assignment of z *= x = " + z );

x = 40;
z = 35;
z /= x ;
println("\tDivision and assignment of z /= x = " + z );

x = 30;
z = 15;
z %= x;
println("\tModulus and assignment of z %= x = " + z );

z <<= 2;
println("\tLeft shift and assignment of z <<= 2 = " + z );

z >>= 2;
println("\tRight shift and assignment of z >>= 2 = " + z );

z &= x;
println("\tBitwise And assignment of z &= 2 = " +z );

z ^= x ;
println("\tBitwise Xor and assignment of z ^= x = " + z );

z |= x ;
println("\tBitwise Or and assignment of z |= x = " + z );
print("\n")
print("\tEnd of Program")
print("\n\n")
}
}
