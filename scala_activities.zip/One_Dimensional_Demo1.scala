// Scala program to accessing an array 
// of the string as name.
object One_Dimensional_Demo1
{
    // Main method
    def main(args: Array[String]) : Unit =  
    {
        // allocating memory of 1D Array of string. 
        var name = Array("Java", "Scala", "Perl", "C","C++","C#" )
       
        print("The second element of an array is: ")
        
        // Accessing an array element
        print("\n")
        print(name(1))
        print("\n")
    }
}