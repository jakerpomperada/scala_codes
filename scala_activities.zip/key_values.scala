object key_values {
   def main(args: Array[String]) : Unit =  {
      val cars = Map("Toyota" -> "White", "Suzuki" -> "Blue", "Honda" -> "Green")

      val nums: Map[Int, Int] = Map()

      println( "Keys in cars: " + cars.keys )
      println( "Values in cars : " + cars.values )
      println( "Check if cars is empty : " + cars.isEmpty )
      println( "Check if nums is empty : " + nums.isEmpty )
   }
}