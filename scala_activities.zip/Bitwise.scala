object Bitwise {
    def main(args: Array[String]) : Unit =  {
    var x = 18;
    var y = 14;
    var z = 0;

    print("\n")
    print("\tBitwise Operators in Scala")
    print("\n\n")

    z = x & y;
    println("\tBitwise And of x & y = " + z );

    z = x | y;
    println("\tBitwise Or of x | y = " + z );

    z = x ^ y;
    println("\tBitwise Xor of x ^ y = " + z );

    z = ~x;
    println("\tBitwise Ones Complement of ~x = " + z );

    z = x << 2;
    println("\tBitwise Left Shift of x << 2 = " + z );

    z = x >> 2;
    println("\tBitwise Right Shift of x >> 2 = " + z );

    z = x >>> 2;
    println("\tBitwise Shift Right x >>> 2 = " + z );
    print("\n")
    print("\tEnd of Program")
    print("\n\n")
}
}