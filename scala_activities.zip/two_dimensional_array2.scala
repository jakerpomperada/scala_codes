object two_dimensional
    { 
        def main(args: Array[String]) : Unit =  
        { 
            val multiArr= Array(Array(100,200,300),Array(400, 500,600))
            
            for(i <- 0 to 1; j <- 0 to 2){
                println("Element "+ i  + j + " = " + multiArr(i)(j))
            }
        } 
} 