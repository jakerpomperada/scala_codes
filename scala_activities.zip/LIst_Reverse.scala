object List_Reverse {
   def main(args: Array[String]) : Unit = {
      val  animals = "Dog" :: ("Cat" :: ("Mouse" :: Nil))
      
      println( "Before reverse animals : " + animals )
      println( "After reverse animals : " + animals.reverse )
   }
}