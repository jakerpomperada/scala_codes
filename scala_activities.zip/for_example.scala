/* for_example.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   January 18, 2022   8:55 PM  Tuesday    
   Bacolod City, Negros Occidental
 */

object for_example {
	
	def main(args: Array[String]) : Unit = {
	
	    print("\n");
    	print("\tFor Loop Example No. 6 Using by in Scala");
        print("\n\n");   
		for(i<-1 to 10 by 2){  
            print("\t");
            println(i)  
        }  
    print("\n");
    print("\tEnd of Program");
    print("\n\n");
    }
}