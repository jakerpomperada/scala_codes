object List_concat  {
   def main(args: Array[String]) : Unit =  {
      val car1 = "toyota" :: ("honda" :: ("nissan" :: Nil))
      val car2 = "ford" :: ("suzuki" :: Nil)

      // use two or more lists with ::: operator
      var car = car1 ::: car2
      println( "car1 ::: car2 : " + car )
      
      // use two lists with Set.:::() method
      car = car1.:::(car2)
      println( "car1.:::(car2) : " + car )

      // pass two or more lists as arguments
      car = List.concat(car1, car2)
      println( "List.concat(car1, car2) : " + car  )
   }
}