/*  highest_lowest.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 2, 2022   12:33 PM    Wednesday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object  highest_lowest {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        val myArray = Array.ofDim[Int](100,1) 
        var val_num =0; 
		var max=0;  var min=0;
	    var repeat='N';

 do

	 {
	    print("\n");
    	print("\tHighest and Lowest Number Using Two-Dimensional Arrays in Scala");
        print("\n\n");  
    	print("\tHow Many Items? : ");
        val_num = scanner.nextInt();

		for (i <- 1 to val_num) {
			print("\tEnter Value in Item No. " + i + " : ");   
           myArray(i)(0) = scanner.nextInt();
		
		} 
	        
	    max = myArray(0)(0);
    	for (i <- 1 to val_num)
    {
        if (max < myArray(i)(0))
            max = myArray(i)(0);
    }
    min = myArray(0)(0);
    for (i <- 1 to val_num)
    {
        if (min > myArray(i)(0))
            min = myArray(i)(0);
    }
		print("\n");
		printf("\t===== DISPLAY RESULT =====");
    	printf("\n\n");
        printf("\tThe Largest Value is %d.",max);
        printf("\n\n");
        printf("\tThe Smallest Value is %d.",min);
        print("\n\n");
		printf("\tDo You Want To Continue? Y/N : ");
		repeat  = scala.io.StdIn.readChar()
		 
	 }  while (repeat.toUpper == 'Y'); 
	   	   print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}