/* math.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February 27, 2022   Sunday  2:22 PM
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object math {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        var myArray = Array.ofDim[Int](2,1) 
	
        print("\n");
    	print("\tBasic Math Operations Using Two-Dimensional Arrays in Scala");
        print("\n\n");   

        /* Input of Two Numbers Here */
		print("\tEnter the first number  : ");
	    var a = myArray(0)(0); 
        a = scanner.nextInt();
		
		print("\tEnter the second number : ");
		var b = myArray(1)(0); 
        b = scanner.nextInt();
        
        /* Basic Math Operations Performs Here */

        var addition = (a+b);
        var subtraction = (a-b);
        var product = (a*b);
        var quotient = (a/b);
		
        /* Display Results Here */

		print("\n");
        println("\tThe sum of " + a + " and " + b + " is " + addition +".");
        println("\tThe difference between " + a + " and " + b + " is " + subtraction +".");
        println("\tThe product of " + a + " and " + b + " is " + product +".");
		println("\tThe quotient of " + a + " and " + b + " is " + quotient +".");
        print("\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}