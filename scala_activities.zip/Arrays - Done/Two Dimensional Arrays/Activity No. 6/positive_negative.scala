/* positive_negative.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 2, 2022  Wednesday   12:17 PM
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object  positive_negative {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        val myArray = Array.ofDim[Int](100,1) 
			
       var val_num =0; var a=0;
	    var result : String="";
        var repeat='N';

 do

	 {
	    print("\n");
    	print("\tPositve and Negative Numbers Using Two-Dimensional Arrays in Scala");
        print("\n\n");  
    	print("\tHow Many Items? : ");
        val_num = scanner.nextInt();

		for (i <- 1 to val_num) {
			print("\tEnter Value in Item No. " + i + " : ");   
           myArray(i)(0) = scanner.nextInt();
		
		} 
	        
			print("\n");
			print("\tThe Positive Numbers are:");
            print("\n");
			// Print All Positive Numbers
			print("\n")
			print("\t")
    		for (a <- 1 to val_num if myArray(a)(0) >= 0) 
			print(" " +  myArray(a)(0)  + " " );
         	print("\n\n");
			print("\tThe Negative Numbers are:");
            println("\n");
			print("\t");
			// Print all Negative Numbers 
    		for (a <- 1 to val_num if myArray(a)(0) < 0) 
			print(" " + myArray(a)(0) + " " );
            print("\n\n");
		    printf("\tDo You Want To Continue? Y/N : ");
		    repeat  = scala.io.StdIn.readChar()
		 
	 }  while (repeat.toUpper == 'Y'); 
	   	   print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}