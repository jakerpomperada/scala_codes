/* multiplication_table.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 6, 2022   9:29 AM    Sunday
   Bacolod City, Negros Occidental
 */


object  multiplication_table {
	
	def main(args: Array[String]) : Unit = {
	
         var myArray= Array.ofDim[Int](11,1)
        
        print("\n");
    	print("\tMultiplication Table Using Two-Dimensional Arrays in Scala");
        print("\n\n");  
        myArray(0)(0) = 0
        myArray(1)(0) = 1
        myArray(2)(0) = 2
        myArray(3)(0) = 3
        myArray(4)(0) = 4
        myArray(5)(0) = 5
        myArray(6)(0) = 6
        myArray(7)(0) = 7
        myArray(8)(0) = 8
        myArray(9)(0) = 9
        myArray(10)(0) = 10
    	
		 for( a <- 1 to 10)  {
			 printf("\t\t");
			 for( b <- 1 to 10)  {
             printf("%4d",myArray(a)(0) * myArray(b)(0));
			 }
		 printf("\n");
		} 
	       print("\n");
           print("\t\t\t\tEnd of Program");
           print("\n\n");
	 
       }
}