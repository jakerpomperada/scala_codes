/* addition.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February 23, 2022  10:24 PM  Wednesday
   Bacolod City, Negros Occidental
 */


object addition {

  
	def main(args: Array[String]) : Unit = {
	    var myArray = Array.ofDim[Int](4,1) 

	    print("\n");
    	print("\tAddition of Three Numbers Using Arrays in Scala");
        print("\n");   
		myArray(0)(0) = 10;
        myArray(1)(0) = 20;
        myArray(2)(0) = 30;
        

        print("\n");
        var sum = myArray(0)(0) + myArray(1)(0) + myArray(2)(0);

        printf("\tThe sum of %d, %d, and %d is %d."
            ,myArray(0)(0),myArray(1)(0),myArray(2)(0),sum);
				
        print("\n\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}