/*  days_week.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 3, 2022  11:06 PM  Thursday
   Bacolod City, Negros Occidental
 */


object days_week {
	
	def main(args: Array[String]) : Unit = {
	
	var days_weeks =  Array.ofDim[String](7,1)
           
        print("\n");
    	print("\tDays of the Week Using Two-Dimensional Arrays in Scala");
        print("\n\n");  
        days_weeks(0)(0) = "Monday"
        days_weeks(1)(0) = "Tuesday"
        days_weeks(2)(0) = "Wednesday"
        days_weeks(3)(0) = "Thursday" 
        days_weeks(4)(0) = "Friday"
        days_weeks(5)(0) = "Saturday"
        days_weeks(6)(0) = "Sunday" 
    	
        printf("\t");
    for {
          i <- 0 until 7
         j <- 0 until 1
   } 
  
   print(s" ${days_weeks(i)(j)}")
    
   
           print("\n\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}