/*  linear_search .scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 6, 2022  8:36 AM   Sunday
   Bacolod City, Negros Occidental */

import java.util.Scanner;

object  linear_search {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        val myArray = Array.ofDim[Int](100,1); 
        var val_num =0; var num_input=0;
	    var c=0; var pos=0;
        var repeat='N';  var done = false;
	
 do

	 {
	    print("\n");
    	print("\tLinear Search Using Two-Dimensional Arrays in Scala");
        print("\n\n");  
    	print("\tHow Many Items? : ");
        val_num = scanner.nextInt();

		for (i <- 1 to val_num) {
			print("\tEnter a Value in Item No. " + i + " : ");   
           myArray(i)(0) = scanner.nextInt();
		
		} 
	      printf("\n");  
			print("\tEnter the number to be search : ");
          num_input = scanner.nextInt();
			print("\n");
				for (i <- 0 to val_num) 
	{
		if(myArray(i)(0)==num_input)
		{
			c=1;
			pos=i+1;
			done = true;
		}
	}
				
	if(c==0)
	{
	printf("\n");
	printf("\tSorry the number %d is not found from the list.",num_input);
	}
	else
	{
		printf("\n");
	    printf("\tThe number %d found at position %d.",num_input,pos-1);
	}
			printf("\n\n");
            printf("\tDo You Want To Continue? Y/N : ");
		    repeat  = scala.io.StdIn.readChar()
		 
	 }  while (repeat.toUpper == 'Y'); 
	   	   print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}