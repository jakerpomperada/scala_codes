/* arrays_example.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February 23, 2022  10:03 PM   Wednesday
   Bacolod City, Negros Occidental
 */

object arrays_example {

    	
   def main(args: Array[String]):Unit = {

        print("\n");
      	print("\tExample of Two-Dimensional Array in Scala");
        print("\n\n");   
		
         var student_scores = Array(Array(56,20,45,30,67),Array(88,34,82,99,63))
             // Creating Two-Dimensional Array 
         
      // Print all the student scores using Two-Dimensional Array
      printf("\t");
      for(a<- 0 to 1){            // Traversing elements using next for loop statement  
           for(b<- 0 to 4){  
           printf("%4d",student_scores(a)(b));
      }
         
         }
        print("\n\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}

}