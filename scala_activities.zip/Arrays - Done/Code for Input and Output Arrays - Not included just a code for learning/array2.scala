object printarray {

  def main(args:Array[String]) = {

    val arr =  Array.ofDim[Int](5,2)


    println("the values of array is ")

    for (i <- 0 to 4; j<-0 until 1) {

      arr(i)(j) = scala.io.StdIn.readInt()

    }


    for {
   i <- 0 until 5
   j <- 0 until 1
 }
 println(s"($i)($j) = ${arr(i)(j)}")
  }

}