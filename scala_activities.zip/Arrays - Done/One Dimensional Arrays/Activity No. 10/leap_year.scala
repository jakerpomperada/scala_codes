/* leap_year.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February  13, 2022   10:10 PM  Sunday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object leap_year {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        val myArray = new Array[Int](100);
        var val_num =0; var a=0;
	    var repeat='N';

 do

	 {
	    print("\n");
    	print("\tLeap Year Using One-Dimensional Arrays in Scala");
        print("\n\n");  
    	print("\tHow Many Items? : ");
        val_num = scanner.nextInt();

		for (i <- 1 to val_num) {
			print("\tEnter Year in Item No. " + i + " : ");   
           myArray(i) = scanner.nextInt();
		 		
		} 
	        print("\n");
            print("\tList of Leap Years");
			print("\n\n");
			for (i <- 1 to val_num) {
			 if ((myArray(i) % 4 == 0) && (myArray(i) % 100 != 0) )
                  printf("\t%4d",myArray(i));
                else if ((myArray(i) % 4 == 0) && (myArray(i) % 100 == 0) && (myArray(i) % 400 == 0) )
                   printf("\t%4d",myArray(i));
		  } 
            print("\n\n");
            print("\tList of Not a Leap Years");
			print("\n\n");
			for (i <- 1 to val_num) {
			 if ((myArray(i) % 4 != 0) && (myArray(i) % 100 == 0) )
                  printf("\t%4d",myArray(i));
                else if ((myArray(i) % 4 != 0) && (myArray(i) % 100 != 0) && (myArray(i) % 400 != 0) )
                   printf("\t%4d",myArray(i));
		  } 


            print("\n\n");
		    printf("\tDo You Want To Continue? Y/N : ");
		    repeat  = scala.io.StdIn.readChar()
		 
	 }  while (repeat.toUpper == 'Y'); 
	   	   print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}