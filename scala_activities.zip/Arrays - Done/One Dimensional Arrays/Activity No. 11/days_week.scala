/*  days_week.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February  14, 2022   10:08 AM  Sunday
   Bacolod City, Negros Occidental
 */


object days_week {
	
	def main(args: Array[String]) : Unit = {
	
	   var days_weeks = Array("Monday", "Tuesday", 
                    "Wednesday", "Thursday", "Friday",
                    "Saturday","Sunday" )
      
	    print("\n");
    	print("\tDays of the Week Using One-Dimensional Arrays in Scala");
        print("\n\n");  
       
    	for ( list_of_days <-days_weeks )
        {
           printf("\t");
           printf("%s\n", list_of_days);
        }
           print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}