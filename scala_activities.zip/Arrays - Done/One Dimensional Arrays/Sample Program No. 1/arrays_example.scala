/* arrays_example.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February 6, 2022   11:18 AM  Sunday
   Bacolod City, Negros Occidental
 */


object arrays_example {

    	
   def main(args: Array[String]):Unit = {

        print("\n");
      	print("\tExample of One-Dimensional Array in Scala");
        print("\n\n");   
		
         var student_scores = Array(56,20,45,30,67,88,34,82,99,63)
      
      // Print all the student scores
      printf("\t");
      for ( x <- student_scores) {
         printf("%4d",x);
      }
        
        print("\n\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}

}