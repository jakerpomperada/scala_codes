/* odd_even.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February  13, 2022   9:33 AM  Sunday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object  odd_even {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        val myArray = new Array[Int](100);
        var val_num =0; var a=0;
	    var result : String="";
        var repeat='N';

 do

	 {
	    print("\n");
    	print("\tOdd and Even Numbers Using One-Dimensional Arrays in Scala");
        print("\n\n");  
    	print("\tHow Many Items? : ");
        val_num = scanner.nextInt();

		for (i <- 1 to val_num) {
			print("\tEnter Value in Item No. " + i + " : ");   
           myArray(i) = scanner.nextInt();
		
		} 
	        
			print("\n");
			print("\tThe ODD numbers are:");
            print("\n");
			// Print all Odd Numbers 
			print("\n")
			print("\t")
    		for (a <- 1 to val_num if myArray(a) % 2 != 0) 
			print(" " +  myArray(a)  + " " );
         	print("\n\n");
			print("\tThe Even numbers are:");
            println("\n");
			print("\t");
			// Print all Even Numbers 
    		for (a <- 1 to val_num if myArray(a) % 2 == 0) 
			print(" " + myArray(a) + " " );
            print("\n\n");
		    printf("\tDo You Want To Continue? Y/N : ");
		    repeat  = scala.io.StdIn.readChar()
		 
	 }  while (repeat.toUpper == 'Y'); 
	   	   print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}