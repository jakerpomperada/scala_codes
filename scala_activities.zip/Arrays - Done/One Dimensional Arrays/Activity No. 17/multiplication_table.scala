/* multiplication_table.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February  27, 2022  8:54 PM  Sunday
   Bacolod City, Negros Occidental
 */


object  multiplication_table {
	
	def main(args: Array[String]) : Unit = {
	
         var myArray= Array(0,1,2,3,4,5,6,7,8,9,10)
        
        print("\n");
    	print("\tMultiplication Table Using One-Dimensional Arrays in Scala");
        print("\n\n");  
    	
		 for( a <- 1 to 10)  {
			 printf("\t");
			 for( b <- 1 to 10)  {
             printf("%4d",myArray(a) * myArray(b));
			 }
		 printf("\n");
		} 
	       print("\n");
           print("\t\t\tEnd of Program");
           print("\n\n");
	 
       }
}