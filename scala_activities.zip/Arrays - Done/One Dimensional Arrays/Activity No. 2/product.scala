/* product.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February 13, 2022   Sunday  8:37 AM
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object product {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        var myArray = new Array[Int](2); 
	
        print("\n\n");
    	print("\tProduct of Two Numbers Using Array in Scala");
        print("\n\n");   
		print("\tEnter the first number : ");
	    var a = myArray(0); 
        a = scanner.nextInt();
		
		print("\n");
		print("\tEnter the second number : ");
		var b = myArray(1); 
        b = scanner.nextInt();

        var product = (a*b);
		
		print("\n");
		println("\tThe product of " + a + " and " + b + " is " + product +".");
        print("\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}