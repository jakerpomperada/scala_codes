/*  square.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February  14, 2022   11:19 AM  Sunday
   Bacolod City, Negros Occidental
 */


object square {
	
  
	def main(args: Array[String]) : Unit = {
	
	   var myArray= Array(0,1,2,3,4,5,6,7,8,9,10)
      
	   print("\n");
    	print("\tSquare a Number Using One-Dimensional Arrays in Scala");
      print("\n\n");  

      print("\tList of Square Numbers");
      print("\n\n"); 

 for( i <- 1 to 10)  {
        printf("\t");
	     printf("%d^2 = %d\n", myArray(i), myArray(i) * myArray(i));
		  }

           print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}