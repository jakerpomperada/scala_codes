/* addition.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February 13, 2022  6:03 am  Sunday
   Bacolod City, Negros Occidental
 */


object addition {

  
	def main(args: Array[String]) : Unit = {
	    var myArray = new Array[Int](4) 

	    print("\n");
    	print("\tAddition of Three Numbers Using Arrays in Scala");
        print("\n");   
		myArray(0) = 10;
        myArray(1) = 20;
        myArray(2) = 30;
        

        print("\n");
        var sum = myArray(0) + myArray(1) + myArray(2);

        printf("\tThe sum of %d, %d, and %d is %d."
            ,myArray(0),myArray(1),myArray(2),sum);
				
        print("\n\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}