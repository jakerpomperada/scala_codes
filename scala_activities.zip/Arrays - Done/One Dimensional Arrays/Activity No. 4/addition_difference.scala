/* addition_difference.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February 13, 2022   Sunday  8:53 AM
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object math {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        var myArray = new Array[Int](2); 
	
        print("\n");
    	print("\tAddition and Subtraction Using One-Dimensional Arrays in Scala");
        print("\n\n");   

        /* Input of Two Numbers Here */
		print("\tEnter the first number  : ");
	    var a = myArray(0); 
        a = scanner.nextInt();
		
		print("\tEnter the second number : ");
		var b = myArray(1); 
        b = scanner.nextInt();
        
        /* Addition and Subtraction Operations Performs Here */

        var addition = (a+b);
        var subtraction = (a-b);
       
		
        /* Display Results Here */

		print("\n");
        println("\tThe sum of " + a + " and " + b + " is " + addition +".");
        println("\tThe difference between " + a + " and " + b + " is " + subtraction +".");
        print("\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}