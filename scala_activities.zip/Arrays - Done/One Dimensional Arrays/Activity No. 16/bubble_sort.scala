/* bubble_sort.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February  16, 2022   2:26 PM    Wednesday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object  bubble_sort {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);

        val myArray = new Array[Int](100);
        var val_num =0; var a=0; var temp=0;
	    var repeat='N'; var b=0;

 do

	 {
	    print("\n");
    	print("\tBubble Sort Using One-Dimensional Arrays in Scala");
        print("\n\n");  
    	print("\tHow Many Items? : ");
        val_num = scanner.nextInt();

		for (i <- 1 to val_num) {
			print("\tEnter Value in Item No. " + i + " : ");   
           myArray(i) = scanner.nextInt();
		
		} 
	        
	printf("\n");	
	printf("\tOriginal Array Arrangement");
    printf("\n");
  for (i <- 1 to val_num) {
	   printf("\t %d ",myArray(i));    
    }    
    for (i <- 1 to val_num)
    {
        
		  for (b <- 1 to val_num-i)
	           if(myArray(b)>myArray(b+1))
            {
                temp=myArray(b);
                myArray(b)=myArray(b+1);
                myArray(b+1)=temp;
            }
    }
  	printf("\n\n");
    printf("\tSorted Array Arrangement");
    printf("\n");
    for (i <- 1 to val_num) {
	   printf("\t%d",myArray(i));      
    }
			printf("\n\n");
            printf("\tDo You Want To Continue? Y/N : ");
		    repeat  = scala.io.StdIn.readChar()
		 
	 }  while (repeat.toUpper == 'Y'); 
	   	   print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}