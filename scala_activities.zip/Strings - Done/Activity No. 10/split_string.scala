/* split_string.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 9, 2022  10:12 PM    Wednesday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object split_string {

   def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);
  
    print("\n");
    print("\tSplit String  Using Scala");
    print("\n\n");
    print("\tGive a Sentence :  ");
    var line = input.nextLine();

    print("\n")
    print("\t===== DISPLAY RESULTS ====\n\n");
    println("\t" + line)
     
     val stringContents = line.split(" ")

     print("\n");   
     println("\tContent of the string are: ")
     print("\n");
    
        for(i <- 0 to stringContents.length-1){
         print("\t")
         println(stringContents(i))
        }
            
    print("\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
   }
   
  }

