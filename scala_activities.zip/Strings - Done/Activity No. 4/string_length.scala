/* string_length.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 7, 2022  10:48  AM  Monday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object string_length {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    var display_result = " ";

    print("\n");
    print("\tFind the Length of the String Using Scala");
    print("\n\n");
    print("\tGive a String :  ");
    var str_sentence = input.nextLine();

    // Code to find the length of the string
    var stringLen = str_sentence.length()
       
     display_result = "\tThe length of the string : " + stringLen
          
    print("\n");
    print(display_result);
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
