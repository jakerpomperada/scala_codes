/* capital_vowels.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 7, 2022 12:06 PM  Monday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object capital_vowels {


   def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    var display_result = " ";

    print("\n");
    print("\tCapital Vowels Using Scala");
    print("\n\n");
    print("\tGive a String :  ");
    var str_string = input.nextLine();

    // Code to replace lower case vowels into upper case vowels
       str_string = str_string.replace('a', 'A');
       str_string = str_string.replace('e', 'E');
       str_string = str_string.replace('i', 'I');
       str_string = str_string.replace('o', 'O');
       str_string  = str_string.replace('u', 'U');

     display_result = "\tThe result : " + str_string
          
    print("\n");
    print(display_result);
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
