/* remove_vowels.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 7, 2022 12:06 PM  Monday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object remove_vowels {


   def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    var display_result = " ";

    print("\n");
    print("\tRemove Vowels Using Scala");
    print("\n\n");
    print("\tGive a String :  ");
    var str_sentence = input.nextLine();

    // Code to count the number of words in a given sentence
        var s1 = "";
        s1 = str_sentence.replaceAll("[aeiouAEIOU]", ""); 

     display_result = "\tString after removing vowel : " + s1
          
    print("\n");
    print(display_result);
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
