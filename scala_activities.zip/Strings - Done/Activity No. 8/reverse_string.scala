/* reverse_string.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 9, 2022  3:29 PM    Wednesday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object reverse_string {

def reverseString(newString: String): String = {
        var revString = ""
        val n = newString.length()
        for(i <- 0 to n-1){
            revString = revString.concat(newString.charAt(n-i-1).toString)
        }
    return revString
    }



   def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

  

    print("\n");
    print("\tReverse a String  Using Scala");
    print("\n\n");
    print("\tGive a String :  ");
    var line = input.nextLine();

    print("\n")
    print("\t===== DISPLAY RESULTS ====\n\n");
    printf("\tThe Reverse of %s is %s." , line,reverseString(line))
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
  
 
  }

