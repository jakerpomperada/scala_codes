/* hello_World.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 6, 2022    12:37 PM   Sunday
   Bacolod City, Negros Occidental
 */

object hell_world {
	
	def main(args: Array[String]) : Unit = {
	
	  var message = "Hello World Welcome To Scala"

      print("\n")  
          print(message)
      print("\n\n")  
		
	}
}