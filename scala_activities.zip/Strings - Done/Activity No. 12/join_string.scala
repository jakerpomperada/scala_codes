/* join_string.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 11, 2022 1:20 PM   Friday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object join_string {

   def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);
  
    print("\n");
    print("\tJoin String Using Scala");
    print("\n\n");
   
    var first_string = "Scala"
    var second_string = " Programming"

    var join_string = first_string.concat(second_string)
       
    print("\t===== DISPLAY RESULTS ====\n\n");
    printf("\tThe Joint String : %s" ,join_string)
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
   }
   
  }

