/* vowels_consonants.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 9, 2022  3:12 PM    Wednesday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object vowels_consonants {


   def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

   var vowels = 0; var consonants = 0;
  
   var a = 0;

    print("\n");
    print("\tCount Vowels and Consonants Using Scala");
    print("\n\n");
    print("\tGive a String or a Sentence :  ");
    var line = input.nextLine();

    line = line.toLowerCase();
    
    while (a < line.length) 
    {
      var ch = line.charAt(a);

      // check if character is any of a, e, i, o, u
      if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
        vowels=vowels+1;
      }

      // check if character is in between a to z
      else if ((ch >= 'a' && ch <= 'z')) {
        consonants=consonants+1;
      }
      
    a=a+1;
    }
    print("\n")
    print("\t===== DISPLAY RESULTS ====\n\n");
    printf("\tNumber of Vowels     : %d \n" ,vowels);
    printf("\tNumber of Consonants : %d " ,consonants);
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
  
 
  }

