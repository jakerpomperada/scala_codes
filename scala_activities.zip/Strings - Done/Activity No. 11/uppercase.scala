/* uppercase.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 11, 2022 10:52 AM  Friday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object uppercase {

   def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);
  
    print("\n");
    print("\tUpper Case a String  Using Scala");
    print("\n\n");
    print("\tGive a String :  ");
    var line = input.nextLine();

    // Code to upper case the given string
    var result = line.toUpperCase();

    print("\n")
    print("\t===== DISPLAY RESULTS ====\n\n");
    printf("\tThe upper case  format : %s" ,result)
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
   }
   
  }

