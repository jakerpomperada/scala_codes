/* lowecase.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 9, 2022  9:54 PM    Wednesday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object lowercase {

   def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);
  
    print("\n");
    print("\tLower Case a String  Using Scala");
    print("\n\n");
    print("\tGive a String :  ");
    var line = input.nextLine();

    // Code to lowercase the given string
    var result = line.toLowerCase();

    print("\n")
    print("\t===== DISPLAY RESULTS ====\n\n");
    printf("\tThe lowercase of %s is %s." , line, result)
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
   }
   
  }

