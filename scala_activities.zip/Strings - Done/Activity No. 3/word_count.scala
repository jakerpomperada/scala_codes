/* word_count.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 6, 2022  10:03 PM   Sunday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object word_count {


 

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    var display_result = " ";

    print("\n");
    print("\tWord Count Using Scala");
    print("\n\n");
    print("\tGive a Sentence :  ");
    var str_sentence = input.nextLine();

    // Code to count the number of words in a given sentence
    val countWords = str_sentence.split(" ").length;

     display_result = "\tThe number of words : " + countWords
          
    print("\n");
    print(display_result);
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
