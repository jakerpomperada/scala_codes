/* greet.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 6, 2022   12:57 PM    Sunday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object greet {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n");
    print("\tGreet a Person Using Scala");
    print("\n\n");
    print("\tWhat is your name?  ");
    var persons_name = input.nextLine();
    
    print("\n");
    print("\tHello " + persons_name + " How are you today? \n");
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
