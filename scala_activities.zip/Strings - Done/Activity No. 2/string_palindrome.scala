/* string_palindrome.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   March 6, 2022   2:44 PM    Sunday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object string_palindrome {

  def string_palindrome_check(s : String ) : Boolean = {
      val sletters = s.toLowerCase.filter(c => c.isLetter)
      (sletters == sletters.reverse)
  }

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    var display_result = " ";

    print("\n");
    print("\tString Palindrome Using Scala");
    print("\n\n");
    print("\tGive a String :  ");
    var str_given = input.nextLine();

    if (string_palindrome_check(str_given))
        {
         display_result = "\tThe given string " + str_given + " is a Palindrome."
        } else {
            display_result = "\tThe given string " + str_given + " is Not a Palindrome."
        }
    
    print("\n");
    print(display_result);
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
