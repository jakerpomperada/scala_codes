object Relational {

def main(args:Array[String]) : Unit = {
var x = 20;
var y = 40;

print("\n")
print("\tRelational Operators in Scala")
print("\n\n")
println("\tEquality of   x == y is : " + (x == y));

println("\tNot Equals of x != y is : " + (x !=y));

println("\tGreater than of x > y is : " + (x > y));

println("\tLesser than of   x < y is : " + (x < y));

println("\tGreater than or Equal to of x >= y is : " + (x >= y));

println("\tLesser than or Equal to of x <= y is : " + (x <= y));
print("\n")
print("\tEnd of Program")
print("\n\n")
}
}