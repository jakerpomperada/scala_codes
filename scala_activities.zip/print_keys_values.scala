object print_keys_values {
def main(args: Array[String]) : Unit = {
val books = Map("title" -> "Introduction To Scala Programming",
"author" -> "Jake Rodriguez Pomperada,MAED-IT,MIT",
"website" -> "www.jakerpomperada.com")
print("\n")
books.keys.foreach { k => // iteration
print( "Key is: " + k )
println(". Value is: " + books(k) )}
print("\n")
}
}