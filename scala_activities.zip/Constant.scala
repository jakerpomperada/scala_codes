object Constant_Example {
def main(args: Array[String]) : Unit = {
val Con1 = "Introduction" // define a constant
val Con2 : String = " To" // define a constant
val Con3 : String = " Scala Programming" // define a constant
print(Con1 + Con2 + Con3);
print("\n\n");
}
}
