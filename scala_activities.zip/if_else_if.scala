object if_else_if {
   def main(args: Array[String]) : Unit =  {
      var x = 40;

      if( x == 20 ){
         print("\n");
         println("Value of X is 20");
         print("\n");
      } else if( x == 30 ){
         print("\n");
         println("Value of X is 30");
         print("\n");
      } else if( x == 40 ){
         print("\n");
         println("Value of X is 40");
         print("\n");
      } else{
         print("\n");
         println("This is else statement");
         print("\n");
      }
   }
}