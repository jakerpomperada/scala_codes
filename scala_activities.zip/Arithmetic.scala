object Arithmetic {

def main(args:Array[String]) : Unit = {
var x = 100;
var y = 20;

print("\n")
print("\tArithmetic Operators in Scala")
print("\n\n")
println("\tAddition of x + y = " + (x + y));

println("\tSubtraction of x - y = " + (x - y));

println("\tMultiplication of x * y = " + (x * y));

println("\tDivision of x / y = " + (x / y));

println("\tModulus of x % y = " + (x % y));
print("\n")
print("\tEnd of Program")
print("\n\n")
}
}