object maps_concat {
def main(args: Array[String]) : Unit = {
val car1 = Map("toyota" -> "red", "ford" -> "black")
val car2 = Map("kia" -> "green", "suzuki" -> "blue")
var cars = car1 ++ car2 // connect two maps
println( "The connected map is : " )
println(cars)
}
}