object List_Tabulate {
   def main(args: Array[String]) : Unit = {
      // Creates 7 elements using the given function.
      val squares = List.tabulate(8)(n => n * n)
      println( "squares : " + squares  )

      val mul = List.tabulate( 3,4 )( _ * _ )      
      println( "multiply : " + mul  )
   }
}