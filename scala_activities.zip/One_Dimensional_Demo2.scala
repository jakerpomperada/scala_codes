// Scala program to updating an array 
// of the string as name.
object One_Dimensional_Demo2
{
    // Main method
    def main(args: Array[String]) : Unit =  
    {
        // allocating memory of 1D Array of string. 
        var name = Array("Java", "Scala", "Perl", "C","C++","C#" )
       
     // Updating an element in an array             
        name(1)="PHP"
        println("After updating array elements are: ")
          
        for ( m1 <-name )
        {
            println(m1 )
        }
    }
}