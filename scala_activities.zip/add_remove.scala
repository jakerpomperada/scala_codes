object add_remove_elements{  
    def main(args:Array[String]) : Unit =  {  
        var map = Map("T"->"Toyota","S"->"Suzuki","N"->"Nissan")             // Creating map  
        println(map("N"))                            // Accessing value by using key  
        var newMap = map+("H"->"Honda")                  // Adding a new element to map  
        println(newMap)  
        var removeElement = newMap - ("T")                // Removing an element from map  
        println(removeElement)  
    }  
}  