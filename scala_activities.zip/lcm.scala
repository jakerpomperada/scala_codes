/*lcm.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   February 2, 2022  3:37 PM  Wednesday
   Bacolod City, Negros Occidental
 */


object  lcm {


   def gcd(a: Int, b: Int):Int=if (b==0) a.abs else gcd(b, a%b)

   def lcm(a: Int, b: Int)=(a*b).abs/gcd(a,b)
	
  def main(args: Array[String]) : Unit = {
	
    
    var a=0; var b=0;  var result=0;
	   var repeat='N';
do

	 {
        
        a=0; b=0; result=0;
		print("\n");
    	print("\tLeast Common Multiple (LCM) Solver Using Do While Statement in Scala");
        print("\n\n");  
    	print("\tGive First Number   : ");
        a=scala.io.StdIn.readInt();
        print("\tGive Second Number  : ");
        b=scala.io.StdIn.readInt();
 	
 	   result = lcm(a, b);
       print("\n");
	   print("\tThe Least Common Multiple (LCM) is "+result+".");
            
            print("\n\n");
		    printf("\tDo You Want To Continue? Y/N : ");
		    repeat  = scala.io.StdIn.readChar()
		 
	 }  while (repeat.toUpper == 'Y'); 
	   	   print("\n");
           print("\tEnd of Program");
           print("\n\n");
	 
       }
}