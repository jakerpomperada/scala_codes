object set_example_one {
def main(args: Array[String]) : Unit =  {
    val numbers = Set(100, 200, 300, 400,500)
    val data: Set[Int] = Set()
println( "Head of Number is : " + numbers.head )
println( "Tail of numbers is : " + numbers.tail )
println( "Check number is empty or not : " + numbers.isEmpty )
println( "Check data is empty or not : " + data.isEmpty )
}
}