object if_else {
   def main(args: Array[String])  : Unit = {
      var x = 100;

      if( x < 90 ){
         print("\n");
         println("This is if statement");
         print("\n");
      } else {
         print("\n");
         println("This is else statement");
         print("\n");
      }
   }
}