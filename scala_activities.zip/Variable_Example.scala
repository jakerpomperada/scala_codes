object Variable_Example {
def main(args: Array[String]) : Unit =  {
var var1, var2, var3 = 50000; // define multi variables
println(var1);
println(var2);
println(var3)

}
}
