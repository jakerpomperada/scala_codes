/* area_cicle.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 2, 2021   9:26 PM  Tuesday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object AreaCircle {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n\n");
    print("\tArea of the Circle Solver Using Scala");
    print("\n\n");
    print("\tEnter the Radius of the Circle : ");

    var radius = input.nextDouble();


    var area = 3.14 * radius * radius

    print("\n");
    print("\tThe Area of Circle is " + f"$area%2.2f" )
    print("\n\n");
    print("\t END OF PROGRAM");
    print("\n\n");
  }
}
