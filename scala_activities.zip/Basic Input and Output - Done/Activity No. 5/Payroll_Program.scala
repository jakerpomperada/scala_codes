/* Payroll_Program.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 09, 2021  10:02 PM Tuesday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object Payroll_Program {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n\n");
    print("\tPayroll Program Using Scala");
    print("\n\n");
    print("\tEnter Employee's Name : ");
    var emp_name = input.nextLine();

    print("\tEnter Days Worked     : ");
    var days = input.nextDouble();

    print("\tEnter Rate Per Day    : ");
    var rate = input.nextDouble();

    var salary = (days * rate);

    print("\n");
    print("\tEmployee's Name       :  " + emp_name + "\n");
    print("\n");
    print("\tThe Gross Salary      : PHP  " + f"$salary%5.2f" )
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
