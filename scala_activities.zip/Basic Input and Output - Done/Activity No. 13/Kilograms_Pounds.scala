
/* Kilograms_Pounds.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 16, 2021  7:35 PM Tuesday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object Kilograms_Pounds {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n\n");
    print("\tKilograms To Pounds Using Scala");
    print("\n\n");
    print("\tEnter Weight in Kilograms : ");
    var kilograms = input.nextDouble();

    var  pounds_value =  (kilograms * 2.20462262185);

    print("\n");
    print("\t===== DISPLAY RESULTS =====");
    print("\n\n");
    print("\t" + kilograms + " kilogram(s) is" + f"$pounds_value%5.2f" + " pound(s).");
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}


