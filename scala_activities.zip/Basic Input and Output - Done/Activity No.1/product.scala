/* product.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   October 31, 2021    Sunday  2:28 PM
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object product {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);
	
        print("\n\n");
    	print("\tProduct of Two Numbers in Scala");
        print("\n\n");   
		print("\tEnter the first number : ");
	    var a = scanner.nextInt();
		
		print("\n");
		print("\tEnter the second number : ");
		var b = scanner.nextInt();

        var product = (a*b);
		
		print("\n");
		println("\tThe product of " + a + " and " + b + " is " + product +".");
        print("\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}