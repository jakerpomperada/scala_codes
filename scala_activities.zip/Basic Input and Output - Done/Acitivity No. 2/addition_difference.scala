/* addition_difference.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   October 31, 2021    Sunday  3:18 PM
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object addition_difference {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);
	
        print("\n\n");
    	print("\tAddition, and Difference  of Two Numbers in Scala");
        print("\n\n");   
		print("\tEnter the first number : ");
	    var a = scanner.nextInt();
		
		print("\n");
		print("\tEnter the second number : ");
		var b = scanner.nextInt();

        var addition = (a+b);
        var difference = (a-b);
		
		print("\n");
		println("\tThe sum of " + a + " and " + b + " is " + addition +".");
        print("\n");
        println("\tThe difference between " + a + " and " + b + " is " + difference +".");
        print("\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}