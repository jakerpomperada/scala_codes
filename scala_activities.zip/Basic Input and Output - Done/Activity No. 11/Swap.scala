/* Swap.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 14, 2021   2:29 PM  Sunday
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object product {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);
	
        print("\n\n");
    	print("\tSwap Two Numbers in Scala");
        print("\n\n");   
		print("\tEnter the First number : ");
	    var a = scanner.nextInt();
		
		print("\n");
		print("\tEnter the Second number : ");
		var b = scanner.nextInt();

        print("\n\n");   
        println("\tValues Before Swapping:\t a= " + a + ", b= " + b)
        
        // swapping
        var temp = a
        a = b
        b = temp
        
        print("\n");
        println("\tValues After Swapping:\t a= " + a + ", b= " + b)
        print("\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}