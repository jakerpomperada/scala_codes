/* Input_Name.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 11, 2021  8:21 PM Thursday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object Input_Name {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n\n");
    print("\tInput Name in Scala");
    print("\n\n");
    print("\tGive Your First Name : ");
    var first_name = input.nextLine();
    print("\tGive Your Last Name  : ");
    var last_name = input.nextLine();
    
    print("\n");
    print("\tHello " + first_name + " "  +  last_name + ". How are you? \n");
     print("\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
