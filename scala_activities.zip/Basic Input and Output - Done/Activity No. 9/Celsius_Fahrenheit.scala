
/* Celsius_Fahrenheit.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 13, 2021  3:21 PM  Saturday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object Celsius_Fahrenheit {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n\n");
    print("\tCelsius To Fahrenheit Using Scala");
    print("\n\n");
    print("\tEnter Celsius Temperature  : ");
    var celsius = input.nextDouble();

    var  fahrenheit = (celsius * 9 / 5 + 32);

    print("\n");
    print("\t===== DISPLAY RESULTS =====");
    print("\n\n");
    print("\tCelsius Temperature    : " + f"$celsius%5.2f \u00B0C");
    print("\n\n");
    print("\tFahreneit Temperature  : " + f"$fahrenheit%5.2f \u00B0C");
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
