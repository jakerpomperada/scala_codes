/* Grade_Solver.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 14, 2021  8:59 PM Sunday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object Grade_Solver {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n\n");
    print("\tGrade Solver Using Scala");
    print("\n\n");
    print("\tEnter Prelim Grade       : ");
    var prelim_grade = input.nextDouble();

    print("\tEnter Midterm Grade      : ");
    var midterm_grade = input.nextDouble();

    print("\tEnter Endterm Grade      : ");
    var endterm_grade = input.nextDouble();

    var final_grade = (prelim_grade * 0.20) + (midterm_grade * 0.30) + (endterm_grade * 0.50);

    print("\n");
    print("\tThe Student Final Grade  :  " + f"$final_grade%2.0f");
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
