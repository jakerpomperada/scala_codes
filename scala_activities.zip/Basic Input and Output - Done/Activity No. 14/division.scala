
/* division.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   January 3, 2022    10: 25 AM
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object division {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n\n");
    print("\tDivision of Two Numbers Using Scala");
    print("\n\n");
    print("\tEnter First Value  : ");
    var num_val_one = input.nextDouble();
    
    print("\tEnter Second Value : ");
    var num_val_two = input.nextDouble();

    var results = (num_val_one / num_val_two);

    print("\n");
    print("\t===== DISPLAY RESULTS =====");
    print("\n\n");
    print("\t" + num_val_one + " / " + num_val_two + " = " + f"$results%5.2f");
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}


