/* money_bill_denominator.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 11, 2021  9:13 PM Thursday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object money_bill_denominator {

  def main(args: Array[String]) : Unit = {

    var amt : Int = 0;  var thousand : Int = 0; 
    var five_hund: Int = 0 ;  var two_hundreds : Int = 0; 
    var hundreds : Int = 0;  var fifty : Int = 0;
    var twentys : Int = 0;

    var input = new Scanner(System.in);

    print("\n");
    print("\tMoney Bill Denominator Using Scala");
    print("\n\n");
    print("\tEnter an Amount : ");
    amt = input.nextInt();

    thousand = amt/1000;
    amt = amt%1000;
    five_hund = amt/500;
    amt = amt%500;
    two_hundreds = amt/200;
    amt = amt%200;
    hundreds = amt/100;
    amt = amt%100;
    fifty = amt/50;
    amt = amt%50;
    twentys = amt/20;
    amt = amt%20;

  print("\n");
  printf("\tDisplay Report\n")
  print("\n");
  printf("\tNumber of 1000 Notes  : " + thousand  + "\n");
  printf("\tNumber of 500 Notes   : "  + five_hund  + "\n");
  printf("\tNumber of 200 Notes   : "  + two_hundreds + "\n");
  printf("\tNumber of 100 Notes   : "  + hundreds + "\n");
  printf("\tNumber of 50 Notes    : "   + fifty + "\n");
  printf("\tNumber of 20 Notes    : "   + twentys  + "\n");

  print("\n");
  print("\tEND OF PROGRAM");
  print("\n\n");
  }
}
