/* basic_math.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   October 31, 2021    Sunday  3:18 PM
   Bacolod City, Negros Occidental
 */

import java.util.Scanner;

object basic_math {
	
	def main(args: Array[String]) : Unit = {
	
	    var scanner = new Scanner(System.in);
	
        print("\n\n");
    	print("\tBasic Math in Scala");
        print("\n\n");   
		print("\tEnter the first number : ");
	    var a = scanner.nextInt();
		
	    print("\tEnter the second number : ");
		var b = scanner.nextInt();

        var addition = (a+b);
        var difference = (a-b);
        var multiply = (a*b);
        var quotient = (a/b);
		
		print("\n");
		println("\tThe sum of " + a + " and " + b + " is " + addition +".");
        println("\tThe difference between " + a + " and " + b + " is " + difference +".");
        println("\tThe product of " + a + " and " + b + " is " + multiply +".");
        println("\tThe quotient between " + a + " and " + b + " is " + quotient +".");
        print("\n");
        print("\tEnd of Program");
        print("\n\n");
		
	}
}