
/* days.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   January 3, 2022    1:31 PM
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object days {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    var days=0;  var years=0; var weeks=0;
   
    print("\n");
    print("\tConvert Days to Years, Weeks and Days Using Scala");
    print("\n\n");
    print("\tHow Many Days : ");
    days = input.nextInt();

    /* Conversion in this portion */
    years = (days / 365);   /* Ignoring leap year */
    weeks = (days % 365) / 7;
    days  = days - ((years * 365) + (weeks * 7));
    
    print("\n");
    print("\t===== DISPLAY RESULTS =====");
    print("\n\n");
    println("\tNumber of Years : " + years);
    println("\tNumber of Weeks : " + weeks);
    println("\tNumber of Days  : " + days);
    print("\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}


