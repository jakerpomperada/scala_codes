class String_Comparison {  
    var s1 = "String in Scala Programming Language"  
    var s2 = "Scala Programming"  
    var s3 = "Scala Programming"  
    def show(){  
        print("\n")
        println(s1 == s2)  
        println(s2 == s3)  
        print("\n")
    }  
}  
  
object StringComparison{  
     def main(args: Array[String]) : Unit =  {  
        var s = new String_Comparison()  
        s.show()  
    }  
}  