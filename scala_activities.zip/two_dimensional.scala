object two_dimensional
    { 
        def main(args: Array[String]) : Unit =  
        { 
            val multiArr= Array.ofDim[Int](3,2)  
            
            multiArr(0)(0) = 100              
            multiArr(0)(1) = 200
            multiArr(1)(0) = 300
            multiArr(1)(1) = 400
            multiArr(2)(0) = 500
            multiArr(2)(1) = 600
          
            for(i <- 0 to 2; j <- 0 to 1){
                println("Element "+ i  + j + " = " + multiArr(i)(j))
            }
        } 
} 