object if_statement {
   def main(args: Array[String]) : Unit =  {
      var y = 43;

      if( y < 80 ){
         print("\n");
         println("\tThis is if statement in Scala.");
         print("\n");
      }
   }
}