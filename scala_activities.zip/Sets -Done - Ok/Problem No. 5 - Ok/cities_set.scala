/* cities_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 16, 2022  2:04 PM   Saturday
   Bacolod City, Negros Occidental
 */


object  cities_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val set_of_cities = Set("Manila", "Mandaluyong City", "Quezon City", 
               "Bacolod City", "Cebu City", "Makati City", "Pasig City", "Angeles City")
        
        print("\n\n");
    	print("\tSet of My Favorite Cities in the Philippines");
        print("\n\n");   

	 // Print the set of my Favorite Cities in the Philippines
        println(set_of_cities);

		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}