/* set_example.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 15, 2022  10:20 PM   Friday
   Bacolod City, Negros Occidental
 */

import scala.collection.immutable._  

object set_example {
	
	def main(args: Array[String]) : Unit = {
	      // Create a String List with 7 elements.
        val brand_of_cars = Set("Acura, Audi, BMW, Bentley, Cadillac, Chevrolet, Chrysler")
        
        print("\n\n");
    	print("\tSet Example in Scala");
        print("\n\n");   

	 // Print the Set of brand of car
        println(brand_of_cars);

		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}