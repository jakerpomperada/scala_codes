/* languages_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022    9:37 PM  Sunday
   Bacolod City, Negros Occidental
 */



object languages_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val programming_languages : Set[String] = Set("Java","C","C++","Cobol",
                                             "Pascal","BASIC","Visual Basic","C#",
                                             "Fortran","Perl","PHP","JavaScritp",
                                             "Python","Assembly Language","Dart",
                                             "Julia","Scala","SQL")     
        print("\n\n");
    	print("\tSet of Programming Languages");
        print("\n\n");   

	 // Print the set of Programming Languages
       
        for(languages_elements<-programming_languages) 
        { 
            println("\t" +languages_elements) 
        } 
    
    	print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}