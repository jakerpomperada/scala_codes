/* noodles_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022    9:00 PM    Sunday
   Bacolod City, Negros Occidental
 */

object noodles_set {
	
	def main(args: Array[String]) : Unit = {
	      
               
        val noodles_set: Set[String] = Set("ABC","Acecook",
                                             "Amino","Chicken Ramen",
                                             "Mamee Chef","Maggi",
                                             "Lucky Me!","Pop Mie", 
                                             "Pot Noodle", "Prima Taste",
                                            "Rara Noodle")                                                         

        print("\n\n");
    	print("\tSet of Instant Noodles Brands");
        print("\n\n");   

	 // Print the set of Mobilephone Brands
       
        for(noodles_elements<-noodles_set) 
        { 
            println("\t" +noodles_elements) 
        } 
    
    	print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}