/* mobile_phone_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022  8:35 PM  Sunday
   Bacolod City, Negros Occidental
 */


object mobile_phone_set {
	
	def main(args: Array[String]) : Unit = {
	      
    
         val mobile_phone_set: Set[String] = Set("Samsung","Apple","Huawei",
                                         "Nokia","Sony","LG","HTM", "Motorola","ZTE")                                                         

        print("\n\n");
    	print("\tSet of Mobilephone Brands");
        print("\n\n");   

	 // Print the set of Mobilephone Brands
       
        for(mobilephone_elements<-mobile_phone_set) 
        { 
            println("\t" +mobilephone_elements) 
        } 
    
    	print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}