/* milk_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022    9:28 PM  Sunday
   Bacolod City, Negros Occidental
 */


object milk_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val milk_brands: Set[String] = Set("Alaska","Bear Brand","Eurocow",
                                             "Emborg","Jolly Cow","Kirkland",
                                             "Nido","Cowhead","Magnolia",
                                             "Nestle","Selecta","MArlene",
                                             "Anchor")     
          
        print("\n\n");
    	print("\tSet of Milk Brands");
        print("\n\n");   

	 // Print the set of Milk Brands
       
        for(milk_elements<-milk_brands) 
        { 
            println("\t" +milk_elements) 
        } 
    
    	print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}