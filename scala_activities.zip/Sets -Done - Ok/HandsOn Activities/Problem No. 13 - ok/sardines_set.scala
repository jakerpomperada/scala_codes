/* sardines_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022    9:05 PM   Sunday
   Bacolod City, Negros Occidental
 */

object sardines_set {
	
	def main(args: Array[String]) : Unit = {
	      
       val sardines_brands: Set[String] = Set("King Oscar","Wild Planet","555",
                                             "Century Tuna","Ligo","Brunswick",
                                             "Nuri","Crown Price","Matiz",
                                             "Beach Cliff","Saba","Master",
                                             "Family Brands", "Mikado","King Oscar",
                                            "Tiny Tot")          
        print("\n\n");
    	print("\tSet of Sardines Brands");
        print("\n\n");   

	 // Print the set of Sardines Brands
       
        for(sardines_elements<-sardines_brands) 
        { 
            println("\t" +sardines_elements) 
        } 
    
    	print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}