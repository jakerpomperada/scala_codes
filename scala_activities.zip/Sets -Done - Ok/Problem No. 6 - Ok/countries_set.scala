/* countries_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022  8:24 AM  Sunday
   Bacolod City, Negros Occidental
 */


object  countries_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val countries = Set("Philippines", "Japan", "China", "USA", "Albania", "Algeria", "Canada")

         val countries_set = Set()
        
        print("\n\n");
    	print("\tSet of My Favorite Countries in the World");
        print("\n\n");   

	 // Print the set of my favorite countries in te world.
        println(countries);

        print("\n\n");
        println( "\tThe first country  : " + countries.head )
        println( "\tThe last country   : " + countries.last )
        println( "\tThe tail  country  : " + countries.tail )
        println( "\tThe country_set set is empty ? " + countries_set.isEmpty)
		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}