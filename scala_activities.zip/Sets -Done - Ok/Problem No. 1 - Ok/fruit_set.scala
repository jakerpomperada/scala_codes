/* fruit_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 16, 2022   8:21 AM   Saturday
   Bacolod City, Negros Occidental
 */


object fruit_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val set_of_fruits = Set("Apples, Pears, Oranges, Bananas, Mangoes, Apricots, Strawberries, Watermelosn, Avocados, Plums");
        
        print("\n\n");
    	print("\tSet of My Favorite Fruits");
        print("\n\n");   

	 // Print the set of my Favorite Fruits
        println(set_of_fruits);

		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}