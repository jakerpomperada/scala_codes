/* nba_teams_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 16, 2022  1:37 PM   Saturday
   Bacolod City, Negros Occidental
 */


import scala.collection.immutable._ 

object  nba_teams_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val set_of_nba_teams = Set("Boston Celtics", "Brooklyn Nets", 
                                    "New York Knicks", "Toronto Raptors", 
                                    "Philadelphia 76ers")
        
        print("\n\n");
    	print("\tSet of My Favorite NBA Teams");
        print("\n\n");   

	 // Print the set of my Favorite NBA Teams
        println(set_of_nba_teams);

        
        print("\n");
        println("\tFirst Team             : "  + set_of_nba_teams.head);    // Returns first element present in the set  
        println("\tThe rest of the Teams  : "  + set_of_nba_teams.tail);   // Returns all elements except first element.  
        println("\tIsEmpty               : "  + set_of_nba_teams.isEmpty); // Returns either true or false 

		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}