/* vegetables_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 16, 2022  11:50 AM   Saturday
   Bacolod City, Negros Occidental
 */


object  vegetables_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val set_of_vegetables = Set("Lettuce, Cabbage, Spinach, Potato, Onion, Garlic,Sweet Potato")
        
        print("\n\n");
    	print("\tSet of My Favorite Vegetables");
        print("\n\n");   

	 // Print the set of my Favorite Vegetables
        println(set_of_vegetables);

		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}