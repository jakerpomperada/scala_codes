/* computer_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022  10:05 AM    Sunday
   Bacolod City, Negros Occidental
 */


object  computer_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val  computer_brands = Set("Lenovo", "HP", "Dell", "Apple","Acer", "Asus", 
                                    "Microsoft", "IBM","Sony","Toshiba")
        
        
        print("\n\n");
    	print("\tSet of Computer Brands");
        print("\n\n");   

	 // Print the set of Computer Brands
        println(computer_brands);

        print("\n\n");
        println( "\tThe first computer brand   : " + computer_brands.head )
        println( "\tThe last  computer brand   : " + computer_brands.last )
        println( "\tThe tail  computer brand   : " + computer_brands.tail )
        println( "\tThe list of computer brand is empty? " + computer_brands.isEmpty)
		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}