/* fruit_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 16, 2022   11:16 AM   Saturday
   Bacolod City, Negros Occidental
 */


object fruit_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val set_of_fruits = Set("Apples", "Pears", "Oranges", "Bananas", "Mangoes", "Apricots", "Strawberries", "WaterMelon", "Avocados", "Plums");
        
        print("\n\n");
    	print("\tSet of My Favorite Fruits");
        print("\n\n");   

	 // Print the set of my Favorite Fruits
        println(set_of_fruits);

        print("\n\n");
        println("\tFirst Fruit : "  + set_of_fruits.head);    // Returns first element present in the set  
        println("\tLast Fruit  : "  + set_of_fruits.tail);   // Returns all elements except first element.  
        println("\tIs Empty    : "  + set_of_fruits.isEmpty); // Returns either true or false 

		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}