/* food_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022  9:25 AM   Sunday
   Bacolod City, Negros Occidental
 */


object  food_set {
	
	def main(args: Array[String]) : Unit = {
	      
        val foods = Set("Bread", "Meat", "Seafood", "Rice", "Pasta", "Cereals", "Soups")

         
        
        print("\n\n");
    	print("\tSet of My Favorite Foods");
        print("\n\n");   

	 // Print the set of my favorite foods
        println(foods);

        print("\n\n");
        println( "\tThe first food   : " + foods.head )
        println( "\tThe last  food   : " + foods.last )
        println( "\tThe tail  food   : " + foods.tail )
        println( "\tThe food set is empty ? " + foods.isEmpty)
		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}