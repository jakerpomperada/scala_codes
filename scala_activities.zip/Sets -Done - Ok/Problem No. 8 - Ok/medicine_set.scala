/* medicine_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022  9:34 AM   Sunday
   Bacolod City, Negros Occidental
 */


object  medicine_set{
	
	def main(args: Array[String]) : Unit = {
	      
        val medicines = Set("Synthroid","Crestor", "Ventolin", "Nexium", "Advair Diskus")
        val medicines_values = Set()
         
        
        print("\n\n");
    	print("\tSet of Medicines");
        print("\n\n");   

	 // Print the set of medicines
        println(medicines);

        print("\n\n");
        println( "\tThe first medicine   : " + medicines.head )
        println( "\tThe last  medicine   : " + medicines.last )
        println( "\tThe tail  medicine   : " + medicines.tail )
        println( "\tThe list of medicine is empty? " + medicines.isEmpty)
		print("\n");
	    print("\tEnd of Program");
        print("\n\n");
		
	}
}