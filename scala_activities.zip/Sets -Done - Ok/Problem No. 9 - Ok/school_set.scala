/* school_set.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   April 17, 2022    9:51 AM    Sunday
   Bacolod City, Negros Occidental
 */


object  school_set {
	
	def main(args: Array[String]) : Unit = {
	      
       val schools = Set("Angeles University Foundation","AMA Computer University",
                          "Bacolod City College","Bago City College")
        
         
        
      print("\n\n");
    	print("\tSet of Schools");
      print("\n\n");   

	 // Print the set of schools
        println(schools);

        print("\n\n");
        println( "\tThe first schools    : " + schools.head )
        println( "\tThe last  schools    : " + schools.last )
        println( "\tThe tail  schools    : " + schools.tail )
        print("\n");
	      print("\tEnd of Program");
        print("\n\n");
		
	}
}