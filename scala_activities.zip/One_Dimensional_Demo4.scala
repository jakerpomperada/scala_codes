// Scala program to concatenate two array 
// by using concat() method
import Array._

object One_Dimensional_Demo4
{
    // Main method
    def main(args: Array[String]) : Unit =  
    {
    var arr1 = Array(10, 20, 30, 40)
    var arr2 = Array(50, 60, 70, 80)
  
    var arr3 = concat( arr1, arr2)
      
    // Print all the array elements
    for ( x <- arr3 ) 
    {
        println( x )
    }
      
    }
}