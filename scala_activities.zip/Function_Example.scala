object Function_Example {  
   def main(args: Array[String]) : Unit =  {  
        var display1 = functionExample(a = 15, b = 2)    // Parameters names are passed during call  
        var display2 = functionExample(b = 15, a = 2)    // Parameters order have changed during call  
        var display3 = functionExample(15,2)             // Only value
        print("\n")
        println(display1+"\n"+display2+"\n"+display3)  
        print("\n")
    }  
    def functionExample(a:Int = 0, b:Int = 0):Int = {   // Parameters with default values as 0  
        a+b  
    }  
}  


	