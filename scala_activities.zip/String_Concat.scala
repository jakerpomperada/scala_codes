object String_Concat {
   def main(args: Array[String]) : Unit =  {
  
   var str1 = "Introduction To";
   var str2 = " Scala Programming";
   var book_title = str1 + str2;
  
    print("\n")
    println( "Book Title : " +  book_title);
    print("\n");
   }
}