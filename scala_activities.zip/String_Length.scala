object String_Length {
   def main(args: Array[String]) : Unit =  {
   var str = "Introduction To Scala Programming By Jake Rodriguez Pomperada";
   var len = str.length();
   print("\n")
   println("Given String : " + str);
   println( "String Length is : " + len );
   print("\n");
   }
}