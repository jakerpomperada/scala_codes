object set+max_min {
def main(args: Array[String]) : Unit =  {
val set1 = Set(100,200,300,400,500,500)
val set2 = Set(600,700,800,900,1000)
var set3 = set1 ++ set2
println("The connected Set is : " )
println(set3)
println( "The minimum element is : " + set3. min )
println( "The maximum element is : " + set3. max )
}
}
