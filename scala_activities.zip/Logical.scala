object Logical {

def main(args:Array[String]) : Unit = {
var x = false
var y = true


print("\n")
print("\tLogical Operators in Scala")
print("\n\n")
println("\tLogical Not of !(x && y) = " + !(x && y) );
println("\tLogical Or of x || y = " + (x || y) );
println("\tLogical And of x && y = " + (x &&y) );
print("\n")
print("\tEnd of Program")
print("\n\n")
}
}