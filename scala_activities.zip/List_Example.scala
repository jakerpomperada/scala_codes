object List_Example {
def main(args: Array[String]) : Unit =  {
val  cars = List("Suzuki", "Toyota", "Mitsubishi","Nissan","Lexus")
val cars0 = List()
println( "The first color is: " + cars.head )
println( "The last color is: " + cars.last )
println( "The tail color is: " + cars.tail )
println( "The cars0 list is empty ? " + cars0.isEmpty )
}
}
