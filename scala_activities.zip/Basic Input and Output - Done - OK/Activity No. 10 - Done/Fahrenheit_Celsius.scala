
/* Fahrenheit_Celsius.scala
   Prof. Jake Rodriguez Pomperada, MAED-IT, MIT
   www.jakerpomperada.blogspot.com and www.jakerpomperada.com
   jakerpomperada@gmail.com
   November 13, 2021  4:05 PM  Saturday
   Bacolod City, Negros Occidental
 */


import java.util.Scanner;

object Fahrenheit_Celsius {

  def main(args: Array[String]) : Unit = {

    var input = new Scanner(System.in);

    print("\n\n");
    print("\tFahrenheit To Celsius Using Scala");
    print("\n\n");
    print("\tEnter Fahrenheit Temperature  : ");
    var fahrenheit = input.nextDouble();

    var  celsius = ((fahrenheit - 32) * 5 / 9);

    print("\n");
    print("\t===== DISPLAY RESULTS =====");
    print("\n\n");
    print("\tFahrenheit Temperature    : " + f"$fahrenheit%5.2f \u00B0F");
    print("\n\n");
    print("\tCelsius Temperature       : " + f"$celsius%5.2f \u00B0C");
    print("\n\n");
    print("\tEND OF PROGRAM");
    print("\n\n");
  }
}
