// Scala program to adding elements in an array 
// of the string as name.
object One_Dimensional_Demo3
{
    // Main method
    def main(args: Array[String]) : Unit =  
    {
        var name = new Array[String](6)
          
        // Adding element in an array 
        name(0)="Java"
        name(1)="Scala"
        name(2)="Pascal"
        name(3)="C"
        name(4)="C++"
        name(5)="C#"
        println("After adding array elements : ")
          
        for ( m1 <-name )
        {
            println(m1 )
        }
      
    }
}